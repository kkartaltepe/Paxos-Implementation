#!/bin/bash
java -cp target/paxos-1.0-jar-with-dependencies.jar edu.utexas.kkartal.chat.client.DefaultClient 2777
